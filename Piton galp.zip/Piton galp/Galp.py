import time
import os
import random

# RGB renklerini terminalde göstermek için ANSI escape kodları kullanılır
def renkli_yazi(metin, renk):
    return f"\033[38;2;{renk[0]};{renk[1]};{renk[2]}m{metin}\033[0m"

def temizle_ekran():
    """Ekranı temizleyen fonksiyon (Windows ve Unix uyumlu)."""
    os.system('cls' if os.name == 'nt' else 'clear')

def kalp_ciz(isim, kayma, renk):
    satirlar = [
        "  ***     ***  ",
        " *****   ***** ",
        "******* *******",
        " ************* ",
        "  ***********  ",
        "   *********   ",
        "    *******    ",
        "     *****     ",
        "      ***      ",
        "       *       "
    ]

    temizle_ekran()
    for satir in satirlar[:5]:
        print(renkli_yazi(" " * kayma + satir.center(30), renk))

    if isim:
        isim_satir = " " * kayma + isim.center(30)
        print(renkli_yazi(isim_satir, renk))

    for satir in satirlar[5:]:
        print(renkli_yazi(" " * kayma + satir.center(30), renk))

def rastgele_renk():
    """Rastgele bir RGB rengi oluşturur."""
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

def hareketli_kalp(isim, dil):
    kayma_miktari = 0
    ileri = True
    while True:
        renk = rastgele_renk()  # Her kare için rastgele bir renk
        kalp_ciz(isim, kayma_miktari, renk)
        time.sleep(0.1)

        if ileri:
            kayma_miktari += 1
        else:
            kayma_miktari -= 1

        if kayma_miktari > 10:
            ileri = False
        elif kayma_miktari < 0:
            ileri = True

def dil_secimi():
    secim = input("Dil Seç / Select Language (Türkçe/English): ").strip().lower()
    if secim in ["türkçe", "turkce", "tr"]:
        return "tr"
    elif secim in ["english", "en"]:
        return "en"
    else:
        print("Geçersiz seçim. Varsayılan olarak Türkçe ayarlandı. / Invalid selection. Defaulting to Turkish.")
        return "tr"

def isim_sor(dil):
    if dil == "tr":
        yanit = input("Kalbe isim eklemek ister misiniz? (E/H): ").strip().lower()
        if yanit == "e":
            return input("Kalbin ortasına yazmak istediğiniz ismi girin: ").strip()
        else:
            return ""
    else:  # English
        yanit = input("Would you like to add a name inside the heart? (Y/N): ").strip().lower()
        if yanit == "y":
            return input("Enter the name you want to display inside the heart: ").strip()
        else:
            return ""

# Program başlangıcı
dil = dil_secimi()
isim = isim_sor(dil)
hareketli_kalp(isim, dil)
